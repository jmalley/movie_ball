THANK YOU FOR PURCHASING!

LICENSE:
------------------- 
Blurry Nature can be used both commercially and for personal use. You must not resell any backgrounds or distribute them.

CONTACT:
-------------------
inspirationfeed@yahoo.com


Enjoy!

Thank you,

Igor Ovsyannykov
